# -*- coding: utf-8 -*-
"""
PROCEDIMENTO UNIFICADO DE HOMOLOGACAO INTEGRAL: LOTOMANIA MODO 4
=================================================================
Script mestre automatizado de verificacao estrita (fail-closed).
Executa 6 etapas sequenciais. Interrompe imediatamente com AssertionError
e codigo de saida 1 diante de qualquer divergencia numerica ou logica:

1. Validacao formal do nucleo matematico (toy model com enumeracao exaustiva,
   casos-limite k=0, 25, 50 e identidade analitica Delta V).
2. Recalculo estatistico rigoroso a partir dos 90 dados brutos individuais
   (analise confirmatoria N=60 e analise historica N=90).
3. Reproducao integral das 189 etapas de selecao e discriminacao dos 7 empates exatos em Q.
4. Reproducao estrutural das carteiras sob alpha in {0.5, 1.0, 2.0} e recalculo dos hashes
   SHA-256 sob Protocolo v1 (default dumps) e Protocolo v2 (compacto canônico).
5. Execucao da suite completa de 20 testes unitarios automatizados.
6. Emissao do parecer final de homologacao executavel.
"""

import math
import random
import json
import os
import sys
import hashlib
import unittest

def nCr(n, r):
    if r < 0 or r > n:
        return 0
    return math.comb(n, r)

def convolucao_hipergeometrica_bivariada(k, t1, t2):
    c_min = max(0, t1 - (50 - k), t2 - (50 - k), t1 + t2 - 20)
    c_max = min(k, t1, t2, 20, k - 20 + t1 + t2)
    if c_min > c_max:
        return 0
    total = 0
    for x11 in range(c_min, c_max + 1):
        total += (
            math.comb(k, x11) *
            math.comb(50 - k, t1 - x11) *
            math.comb(50 - k, t2 - x11) *
            math.comb(k, 20 - t1 - t2 + x11)
        )
    return total

def calcular_valor_p_student(t_stat, df):
    t_val = abs(t_stat)
    x = df / (df + t_val**2)
    a = df / 2.0
    b = 0.5
    log_B = math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)
    series_sum = 0.0
    term = 1.0
    for k in range(160):
        val = (a / (a + k)) * term * (x ** k)
        series_sum += val
        term *= (0.5 + k) / (k + 1)
        if val < 1e-25 * series_sum:
            break
    p_two_tailed = (x ** a) * series_sum / (a * math.exp(log_B))
    return min(1.0, max(0.0, p_two_tailed))

print("=" * 95)
print("PROCEDIMENTO DE HOMOLOGACAO INTEGRAL: LOTOMANIA MODO 4 (FAIL-CLOSED)")
print("=" * 95)

# -------------------------------------------------------------------------------------------------
# ETAPA 1: NUCLEO MATEMATICO (TOY MODEL, CASOS-LIMITE E DELTA V) COM BLOQUEIO FAIL-CLOSED
# -------------------------------------------------------------------------------------------------
print("\n[ETAPA 1/6] Validacao Formal do Nucleo Matematico:")
import itertools
N_toy, M_toy, D_toy = 10, 5, 4
univ_toy = set(range(N_toy))
sorteios_toy = list(itertools.combinations(univ_toy, D_toy))
divergencias_toy = 0
for k_toy in range(M_toy + 1):
    g1_toy = set(range(M_toy))
    g2_toy = set(range(M_toy - k_toy, 2 * M_toy - k_toy))
    for t1_toy in range(D_toy + 1):
        for t2_toy in range(D_toy + 1):
            ex_count = sum(1 for d in sorteios_toy if len(g1_toy.intersection(d)) == t1_toy and len(g2_toy.intersection(d)) == t2_toy)
            r11, r10, r01, r00 = k_toy, M_toy - k_toy, M_toy - k_toy, N_toy - 2 * M_toy + k_toy
            c_min = max(0, t1_toy - r10, t2_toy - r01, t1_toy + t2_toy - D_toy)
            c_max = min(k_toy, t1_toy, t2_toy, D_toy, r00 - D_toy + t1_toy + t2_toy)
            form_count = 0
            if c_min <= c_max:
                for x in range(c_min, c_max + 1):
                    form_count += (
                        math.comb(r11, x) *
                        math.comb(r10, t1_toy - x) *
                        math.comb(r01, t2_toy - x) *
                        math.comb(r00, D_toy - t1_toy - t2_toy + x)
                    )
            if ex_count != form_count:
                divergencias_toy += 1

print(f"  Toy Model (150 configuracoes): {divergencias_toy} divergencias encontradas.")
if divergencias_toy == 0:
    print("  Status Toy Model: CONFORME")
else:
    print("  Status Toy Model: REPROVADO")
    raise AssertionError(f"Auditoria falhou na Etapa 1: {divergencias_toy} divergencias no toy model.")

# Casos Limite Lotomania
faixas_win = [0, 15, 16, 17, 18, 19, 20]
r_win_0 = sum(convolucao_hipergeometrica_bivariada(0, t1, t2) for t1 in faixas_win for t2 in faixas_win)
r_win_50 = sum(convolucao_hipergeometrica_bivariada(50, t1, t2) for t1 in faixas_win for t2 in faixas_win)
c50_20 = nCr(50, 20)
suporte_bilhete = sum(nCr(50, t) * nCr(50, 20 - t) for t in faixas_win)
assert r_win_0 == 2 * c50_20, f"Falha no caso-limite k=0: {r_win_0} != {2*c50_20}"
assert r_win_50 == suporte_bilhete, f"Falha no caso-limite k=50: {r_win_50} != {suporte_bilhete}"
print("  Casos-Limite Lotomania (k=0 e k=50): CONFORME (100% identico)")

# Identidade Delta V
rnd_v = random.Random(42)
c19 = [set(rnd_v.sample(range(1, 101), 50)) for _ in range(19)]
u_v = {n: sum(1 for jg in c19 if n in jg) for n in range(1, 101)}
m_ant = sum(u_v.values()) / 100.0
v1 = sum((u_v[n] - m_ant)**2 for n in range(1, 101))
cand_v = set(rnd_v.sample(range(1, 101), 50))
u_nov = u_v.copy()
for n in cand_v: u_nov[n] += 1
m_nov = sum(u_nov.values()) / 100.0
v2 = sum((u_nov[n] - m_nov)**2 for n in range(1, 101))
assert abs((v2 - v1) - (2.0 * sum(u_v[n] - m_ant for n in cand_v) + 25.0)) < 1e-9
print("  Identidade Delta V = 2*sum(u - m_ant) + 25: CONFORME (Exatidao absoluta)")

# -------------------------------------------------------------------------------------------------
# ETAPA 2: RECALCULO ESTATISTICO RIGOROSO DOS 90 DADOS BRUTOS INDIVIDUAIS
# -------------------------------------------------------------------------------------------------
print("\n[ETAPA 2/6] Recalculo Estatistico dos 90 Dados Brutos Individuais:")
b1 = [480, 172, 435, 152, 212, 240, 510, 255, 484, 206, 418, 429, 214, 171, 479, 190, 348, 282, 291, 788, 435, 110, 423, 539, 217, 517, 354, 418, 333, 48]
b2 = [629, 363, 52, 338, 523, 492, 266, 587, 363, 241, 203, 340, 241, 284, 126, 165, 9, 222, 230, 329]
b3 = [553, 304, 465, 299, 615, 87, 237, 447, 291, 349, 447, 547, 421, 598, 304, 225, 351, 169, 234, 228]
b4 = [419, 469, 105, 309, 339, 97, 160, 153, 205, 261, 436, 446, 252, 475, 192, 97, 40, 545, 153, 180]

conf_60 = b2 + b3 + b4
assert len(conf_60) == 60
soma_conf = sum(conf_60)
assert soma_conf == 18507, f"Soma confirmatoria incorreta: {soma_conf}"
m_conf = soma_conf / 60.0
assert abs(m_conf - 308.45) < 1e-9
var_conf = sum((x - m_conf)**2 for x in conf_60) / 59.0
s_conf = math.sqrt(var_conf)
se_conf = s_conf / math.sqrt(60.0)
t_conf = m_conf / se_conf
p_conf = calcular_valor_p_student(t_conf, 59)
p_sinais_60 = 0.5 ** 60

print(f"  Analise Confirmatoria (60 rodadas):")
print(f"    Saldo = +{soma_conf} | Media = +{m_conf:.4f} | s_D = {s_conf:.6f} | t = {t_conf:.6f}")
print(f"    Valor-p bilateral (df=59): {p_conf:.6e} (auditado: 4.562890e-22)")
print(f"    Teste dos Sinais (60/60):   {p_sinais_60:.6e} (auditado: 8.673617e-19)")
assert abs(t_conf - 15.200479) < 1e-4, f"Divergencia em t_conf: {t_conf}"
assert abs(p_conf - 4.562890e-22) < 1e-25, f"Divergencia em p_conf: {p_conf}"

# Global 90
glob_90 = b1 + conf_60
assert len(glob_90) == 90
soma_glob = sum(glob_90)
assert soma_glob == 28657, f"Soma global incorreta: {soma_glob}"
m_glob = soma_glob / 90.0
var_glob = sum((x - m_glob)**2 for x in glob_90) / 89.0
s_glob = math.sqrt(var_glob)
se_glob = s_glob / math.sqrt(90.0)
t_glob = m_glob / se_glob
p_glob = calcular_valor_p_student(t_glob, 89)
p_sinais_90 = 0.5 ** 90

print(f"  Analise Historica Global (90 rodadas):")
print(f"    Saldo = +{soma_glob} | Media = +{m_glob:.4f} | s_D = {s_glob:.6f} | t = {t_glob:.6f}")
print(f"    Valor-p bilateral (df=89): {p_glob:.6e} (auditado: 2.892859e-33)")
print(f"    Teste dos Sinais (90/90):   {p_sinais_90:.6e} (auditado: 8.077936e-28)")
assert abs(t_glob - 19.117130) < 1e-4, f"Divergencia em t_glob: {t_glob}"
print("  Status Estatistico: CONFORME (Recalculo exato de todas as metricas)")

# -------------------------------------------------------------------------------------------------
# ETAPA 3: REPRODUCAO INTEGRAL DAS 189 ETAPAS DE INVARIANCIA E 7 EMPATES EXATOS
# -------------------------------------------------------------------------------------------------
print("\n[ETAPA 3/6] Reproducao da Invariancia do Minimizador (189 Etapas x 79 Concorrentes):")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from demonstracao_invariancia_argmin import analisar_fielmente
relatorio_invariancia = analisar_fielmente()

tot_etapas = 0
minimos_estritos = 0
empates_exatos_Q = 0
empates_registrados = []

for rodada_idx, etapas in relatorio_invariancia:
    for e in etapas:
        tot_etapas += 1
        m05 = e['min_margem_05']
        m20 = e['min_margem_20']
        if m05 > 1e-9 and m20 > 1e-9:
            minimos_estritos += 1
        elif abs(m05) <= 1e-9 and abs(m20) <= 1e-9:
            empates_exatos_Q += 1
            empates_registrados.append((tot_etapas, rodada_idx, e['etapa'], e['best_A'], e['best_B'], e['second_A'], e['second_B']))
        else:
            raise AssertionError(f"Falha de invariancia na etapa {tot_etapas}: margem negativa!")

print(f"  Total de Etapas Analisadas:                {tot_etapas} (exigido: exatamente 189)")
print(f"  Minimos Estritos (margem > 0):             {minimos_estritos} ({minimos_estritos/tot_etapas*100:.2f}%)")
print(f"  Empates Algebricos Exatos em Q:            {empates_exatos_Q} ({empates_exatos_Q/tot_etapas*100:.2f}%)")
assert tot_etapas == 189, f"Quantidade de etapas incorreta: {tot_etapas}"
assert minimos_estritos == 182, f"Quantidade de minimos estritos incorreta: {minimos_estritos}"
assert empates_exatos_Q == 7, f"Quantidade de empates incorreta: {empates_exatos_Q}"

# Conferir exatidao dos 7 empates em Q (Delta A == 0 e Delta B == 0)
print("  Conferindo individualmente os 7 empates exatos em Q:")
for (step_g, r_idx, b_idx, a1, b1_val, a2, b2_val) in empates_registrados:
    delta_A = abs(a2 - a1)
    delta_B = abs(b2_val - b1_val)
    print(f"    Etapa {step_g:3d} (Rodada {r_idx}, Bilhete {b_idx}): Delta A = {delta_A:.6f}, Delta B = {delta_B:.6f} -> Delta C(alpha) = 0 identico")
    assert delta_A < 1e-9 and delta_B < 1e-9, f"Divergencia no empate da etapa {step_g}!"

print("  Status Invariancia: CONFORME (182 minimos estritos e 7 empates exatos comprovados)")

# -------------------------------------------------------------------------------------------------
# ETAPA 4: RECALCULO DOS HASHES SHA-256 E COMPARACAO ESTRUTURAL DAS CARTEIRAS
# -------------------------------------------------------------------------------------------------
print("\n[ETAPA 4/6] Recalculo dos Hashes SHA-256 sob Protocolos v1 e v2:")
from teste_sensibilidade_pesos import gerar_carteira_custom

hashes_auditados_v1 = [
    "a98c0b0267b1c2d91c630b363bb9be6744dd1d2a6d6943d447f869d705844f0f",
    "c5c3f21ca9bee8ad107d169619763f6a6e527b33e08d343423feabc4be5fbb71",
    "8a50e329b767a1a0f7394646265d408d47a16e2dedd1194e749fb286c77b035e",
    "5d6579b2f452eb826fe702017875c24624552b187563223b874d4c4a884ff07b",
    "560233f78dbdc071c4cf41005d7aa98ce507b30e073683b022492a73382b9f5c",
    "56ca8dd40c00e11b907a740179fd4fbc851b5a0b4fd0c9be4cd96c1523583455",
    "a9abe41b8d391690c34c4c25f6cdb44455c1d1b175eb3e0730c369b078c797bf",
    "ccb4390a4a9383bf7b20e662817b4360b51782e503d163ebd8b806903910c13c",
    "dbf05f13b93f5d9b849f67ef927ee640101657b0f22eebc1583ffe2a6086c3f0",
    "d5faaad0be1cb03cc471d4e94f39491a5106e565f8198889cf865d2059ce8480"
]

hashes_auditados_v2 = [
    "31a34473b0fe1e09f00dca01cebccc2a96abc59331bb472df926d2735a3b211f",
    "a9764997aafb36c8357b9dde03880e0371873899a55b1c8953924c06aded9064",
    "8e0470f2c55fbee21074a1932557fffa0a71a3116856965d2397d180dc019d10",
    "2131a62d501d235e039693aef18cfae839adebe083e8423cdc81a871f15cd55f",
    "0a22ae4b8e28f9bebfec4af98fff26775f29403e55e5ee71bfae718628705d2c",
    "e527bf00e3f295476561be3892f69b4c076561b0192fad389cb70666c699caba",
    "fbb9081b8ec614f97c146842a1a81c64909fa84e1dfe732d927972b426362198",
    "ba553f4a1f3be3b8f981bca7db9fb25f0249f056eb0f9451ce0c292ed7b984cf",
    "5320296decd82a10bd4613625407c578bb32b62edce319b936019a6d2ef7f1c8",
    "8fcf590b3767542663588bda426c35221f8debdfd09bb512c298c083106d21b1"
]

for r in range(1, 11):
    seed_c = 330000 + r
    c_padrao = gerar_carteira_custom(30.0, 0.05, seed=seed_c)
    c_meios = gerar_carteira_custom(15.0, 0.025, seed=seed_c)
    c_dobro = gerar_carteira_custom(60.0, 0.10, seed=seed_c)
    
    # 1. Comparacao estrutural direta (dezenas exatas de todos os bilhetes)
    assert c_padrao == c_meios == c_dobro, f"Falha na identidade estrutural da rodada {r}!"
    
    # 2. Protocolo v1 (default dumps com espacos)
    hv1_p = hashlib.sha256(json.dumps(c_padrao).encode('utf-8')).hexdigest()
    hv1_m = hashlib.sha256(json.dumps(c_meios).encode('utf-8')).hexdigest()
    hv1_d = hashlib.sha256(json.dumps(c_dobro).encode('utf-8')).hexdigest()
    assert hv1_p == hv1_m == hv1_d == hashes_auditados_v1[r - 1], f"Divergencia no hash v1 da rodada {r}!"
    
    # 3. Protocolo v2 (compact dumps sem espacos)
    hv2_p = hashlib.sha256(json.dumps(c_padrao, separators=(',', ':')).encode('utf-8')).hexdigest()
    hv2_m = hashlib.sha256(json.dumps(c_meios, separators=(',', ':')).encode('utf-8')).hexdigest()
    hv2_d = hashlib.sha256(json.dumps(c_dobro, separators=(',', ':')).encode('utf-8')).hexdigest()
    assert hv2_p == hv2_m == hv2_d == hashes_auditados_v2[r - 1], f"Divergencia no hash v2 da rodada {r}!"

print("  Identidade Estrutural das 10 Carteiras sob alpha in {0.5, 1.0, 2.0}: 100% COMPROVADA")
print("  Hashes SHA-256 sob Protocolo v1 (Default): 10/10 CONFERIDOS")
print("  Hashes SHA-256 sob Protocolo v2 (Compacto): 10/10 CONFERIDOS")
print("  Status Hashes: CONFORME")

# -------------------------------------------------------------------------------------------------
# ETAPA 5: EXECUCAO DA SUITE COMPLETA DE 20 TESTES UNITARIOS AUTOMATIZADOS
# -------------------------------------------------------------------------------------------------
print("\n[ETAPA 5/6] Execucao da Suite Completa de 20 Testes Unitarios:")
import test_validacao_matematica_rwin
import test_motor_lotomania
import test_motor_lotomania_evolution

loader = unittest.TestLoader()
suite = unittest.TestSuite()
suite.addTests(loader.loadTestsFromModule(test_validacao_matematica_rwin))
suite.addTests(loader.loadTestsFromModule(test_motor_lotomania))
suite.addTests(loader.loadTestsFromModule(test_motor_lotomania_evolution))

runner = unittest.TextTestRunner(verbosity=1)
resultado_testes = runner.run(suite)

print(f"  Testes Executados: {resultado_testes.testsRun} | Falhas: {len(resultado_testes.failures)} | Erros: {len(resultado_testes.errors)}")
if not (resultado_testes.wasSuccessful() and resultado_testes.testsRun == 20):
    print("  Status Testes: REPROVADO")
    raise AssertionError("Falha na execucao da suite de 20 testes unitarios.")
print("  Status Testes: CONFORME (20/20 aprovados com 0 falhas e 0 erros)")

# -------------------------------------------------------------------------------------------------
# ETAPA 6: EMISSAO DO PARECER CONCLUSIVO
# -------------------------------------------------------------------------------------------------
print("\n" + "=" * 95)
print("PARECER TECNICO CONCLUSIVO: HOMOLOGACAO DE PRODUCAO APROVADA COM EXITO INTEGRAL")
print("Todas as 6 etapas foram validadas com bloqueio estrito fail-closed.")
print("=" * 95)
